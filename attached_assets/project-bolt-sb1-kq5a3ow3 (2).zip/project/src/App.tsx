import React, { useState } from 'react';
import { FileUp, Download, Upload, Menu, Search, Home, Book, Award, Users, Info } from 'lucide-react';

interface TableData {
  [key: string]: string | number;
}

function App() {
  const [tableData, setTableData] = useState<TableData[]>([]);
  const [showDownload, setShowDownload] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleFileUpload = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const file = formData.get('file') as File;
    
    if (!file) {
      alert('Please select a file first!');
      return;
    }

    console.log('File selected:', file.name);
    setShowDownload(true);
    
    setTableData([
      { id: 1, name: 'Sample Data 1', value: 100 },
      { id: 2, name: 'Sample Data 2', value: 200 },
    ]);
  };

  const handleDownload = () => {
    console.log('Downloading Excel file...');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-[#1a237e] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <img 
              src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=48&h=48&fit=crop" 
              alt="Government Logo" 
              className="h-12"
            />
            <div>
              <h1 className="text-lg font-bold">PDF to Excel Converter</h1>
              <p className="text-sm">Government of India Initiative</p>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <Search className="h-5 w-5" />
            <button className="text-sm hover:text-gray-300">Skip to Main Content</button>
            <button className="text-sm hover:text-gray-300">Screen Reader</button>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-white shadow">
        <div className="container mx-auto px-4">
          <div className="relative">
            <div className="flex justify-between items-center h-16">
              <div className="flex">
                <button 
                  className="md:hidden p-2"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                  <Menu className="h-6 w-6" />
                </button>
                <div className="hidden md:flex items-center space-x-8">
                  <a href="#" className="flex items-center text-gray-700 hover:text-blue-600">
                    <Home className="h-4 w-4 mr-1" />
                    Home
                  </a>
                  <a href="#" className="flex items-center text-gray-700 hover:text-blue-600">
                    <Book className="h-4 w-4 mr-1" />
                    Documentation
                  </a>
                  <a href="#" className="flex items-center text-gray-700 hover:text-blue-600">
                    <Award className="h-4 w-4 mr-1" />
                    Certifications
                  </a>
                  <a href="#" className="flex items-center text-gray-700 hover:text-blue-600">
                    <Users className="h-4 w-4 mr-1" />
                    About Us
                  </a>
                  <a href="#" className="flex items-center text-gray-700 hover:text-blue-600">
                    <Info className="h-4 w-4 mr-1" />
                    Help
                  </a>
                </div>
              </div>
            </div>
            
            {/* Mobile Menu */}
            {isMenuOpen && (
              <div className="md:hidden absolute top-16 left-0 w-full bg-white shadow-lg z-50">
                <div className="px-2 pt-2 pb-3 space-y-1">
                  <a href="#" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Home</a>
                  <a href="#" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Documentation</a>
                  <a href="#" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Certifications</a>
                  <a href="#" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">About Us</a>
                  <a href="#" className="block px-3 py-2 text-gray-700 hover:bg-gray-100">Help</a>
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <FileUp className="mx-auto h-12 w-12 text-[#1a237e]" />
            <h2 className="mt-4 text-2xl font-bold text-[#1a237e]">
              PDF to Excel Converter
            </h2>
            <p className="mt-2 text-gray-600">
              Official tool for converting PDF documents to Excel format
            </p>
          </div>

          <form onSubmit={handleFileUpload} className="mb-8">
            <div className="flex items-center justify-center w-full">
              <label className="w-full flex flex-col items-center px-4 py-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 cursor-pointer hover:border-[#1a237e]">
                <Upload className="h-8 w-8 text-gray-400" />
                <span className="mt-2 text-sm text-gray-500">
                  Select a PDF file
                </span>
                <input
                  type="file"
                  name="file"
                  className="hidden"
                  accept=".pdf"
                />
              </label>
            </div>
            <div className="mt-4">
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#1a237e] hover:bg-[#283593] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1a237e]"
              >
                Upload and Process
              </button>
            </div>
          </form>

          {tableData.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Extracted Data
              </h3>
              <div className="overflow-x-auto bg-white border border-gray-200 rounded-lg">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      {Object.keys(tableData[0]).map((header) => (
                        <th
                          key={header}
                          className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {tableData.map((row, index) => (
                      <tr key={index}>
                        {Object.values(row).map((value, i) => (
                          <td
                            key={i}
                            className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                          >
                            {value}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {showDownload && (
            <button
              onClick={handleDownload}
              className="mt-6 w-full flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              <Download className="mr-2 h-5 w-5" />
              Download Excel
            </button>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1a237e] text-white mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-gray-300">Home</a></li>
                <li><a href="#" className="hover:text-gray-300">Documentation</a></li>
                <li><a href="#" className="hover:text-gray-300">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <ul className="space-y-2">
                <li>Email: support@example.gov.in</li>
                <li>Phone: +91-11-XXXXXXXX</li>
                <li>Address: New Delhi, India</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Important Information</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-gray-300">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-gray-300">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-gray-300">Disclaimer</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-blue-800 text-center">
            <p>&copy; 2024 Government of India. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;